export default [
  {
    type: 'input',
    name: 'urls',
    message: 'File url lists:'
  },
  {
    type: 'input',
    name: 'folderName',
    message: 'Destination folder name:'
  }
]
