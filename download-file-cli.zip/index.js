#!/usr/bin/env node

require = require('esm')(module)

module.exports = require('./src/index.js')
